# NCE Lives

Main Site: https://ncehk2019.github.io/nce-live/

Mirror Site: https://nce-live.web.app/

Data Source Repo: https://github.com/ncehk2019/nce-live-datasrc

Our telegram channel: https://t.me/ncelive

Feel free to raise issue if you have any suggestion or question. 
